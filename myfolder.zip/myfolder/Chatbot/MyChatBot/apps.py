from django.apps import AppConfig


class MychatbotConfig(AppConfig):
    name = 'MyChatBot'
